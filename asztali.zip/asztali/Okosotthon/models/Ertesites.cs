using System;

namespace MyApp
{
    public abstract class Ertesites
    {
        public Ertesites(string tartalom, DateTime datum)
        {
            Tartalom = tartalom;
            Datum = datum;
        }

        public string Tartalom { get; set; }
        public DateTime Datum { get; set; }

        public abstract void kuld(string uzenet = "");
    }
}