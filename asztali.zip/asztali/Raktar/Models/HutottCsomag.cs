namespace Raktar
{
    public class HutottCsomag : Csomag
    {
        public HutottCsomag(string id, int suly) : base(id, suly)
        {
            Id = id;
            Suly = suly;
        }

        public override string csomagolas()
        {
            return "Csomagolás módja: Hőszigetelt dobozba kerül, jégakkuval.";
        }
    }
}