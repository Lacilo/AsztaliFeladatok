namespace Kozlekedes
{
    public class Vonalbusz : Utazas
    {
        public Vonalbusz(int alapdij, int megtettKm) : base(alapdij, megtettKm)
        {

        }

        public override int arSzamitas(){
            return Alapdij + (MegtettKm * 30);
        }
    }
}