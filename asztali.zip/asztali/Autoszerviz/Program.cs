﻿using System;

namespace Szerviz
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}