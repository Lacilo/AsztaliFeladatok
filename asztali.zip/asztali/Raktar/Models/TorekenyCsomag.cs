namespace Raktar
{
    public class TorekenyCsomag : Csomag
    {
        public TorekenyCsomag(string id, int suly) : base(id, suly)
        {
            Id = id;
            Suly = suly;
        }

        public override string csomagolas()
        {
            return "Csomagolás módja: Buborékfóliába tekerik, majd ütésálló dobozba teszik.";
        }
    }
}