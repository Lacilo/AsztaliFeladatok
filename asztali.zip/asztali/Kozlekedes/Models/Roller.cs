namespace Kozlekedes
{
    public class Roller : Utazas
    {
        public Roller(int alapdij, int megtettKm) : base(alapdij, megtettKm)
        {

        }

        public override int arSzamitas(){
            return MegtettKm * 120;
        }
    }
}