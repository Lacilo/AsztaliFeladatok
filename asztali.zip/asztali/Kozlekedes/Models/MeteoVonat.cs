namespace Kozlekedes
{
    public class MeteoVonat : Utazas
    {
        public MeteoVonat(int alapdij, int megtettKm) : base(alapdij, megtettKm)
        {

        }

        public override int arSzamitas(){
            return (Alapdij * 2) + (MegtettKm * 50);
        }
    }
}