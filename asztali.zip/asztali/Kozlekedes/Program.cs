﻿using System;

namespace Kozlekedes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}