namespace Kozlekedes
{
    public abstract class Utazas
    {
        public Utazas(int alapdij, int megtettKm)
        {
            Alapdij = alapdij;
            MegtettKm = megtettKm;
        }

        public int Alapdij { get; set; }
        public int MegtettKm { get; set; }

        public abstract int arSzamitas();
    }
}