﻿using System;

namespace MyApp
{
    internal class Program
    {
        public static List<Ertesites> ertesitesek = new List<Ertesites> {};

        static void Main(string[] args)
        {
            Email e1 = new Email("a", DateTime.UtcNow, "cim1", "targy1");
            Sms sms1 = new Sms("sms", DateTime.Now, "06701234567");

            ErtesitesController eController = new ErtesitesController(new List<Ertesites> {});

            eController.AddErtesites(e1);
            eController.AddErtesites(sms1);

            eController.SendRiasztasToAllErtesites("Riasztás");
        }
    }
}