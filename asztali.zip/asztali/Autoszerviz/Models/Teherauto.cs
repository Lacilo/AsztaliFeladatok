namespace Szerviz
{
    public class Teherauto : Jarmu
    {
        public double MaxTeherbiras { get; set; }

        public Teherauto(
            string rendszam,
            int gyartasiEv,
            string allapot,
            double maxTeherbiras)
            : base(rendszam, gyartasiEv, allapot)
        {
            MaxTeherbiras = maxTeherbiras;
        }

        public override void Szervizvizsga()
        {
            Console.WriteLine(
                $"{Rendszam}: teherautó szervizvizsgálata"
            );

            Console.WriteLine("- Fékpad vizsgálat");
            Console.WriteLine("- Tengelyterhelés mérése");
            Console.WriteLine("- Motor ellenőrzése");
            Console.WriteLine(
                $"- Maximális teherbírás: {MaxTeherbiras} tonna"
            );
        }
    }
}