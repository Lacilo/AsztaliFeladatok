namespace Szerviz
{
    public abstract class Jarmu
    {
        public string Rendszam { get; set; }
        public int GyartasiEv { get; set; }
        public string Allapot { get; set; }

        public Jarmu(string rendszam, int gyartasiEv, string allapot)
        {
            Rendszam = rendszam;
            GyartasiEv = gyartasiEv;
            Allapot = allapot;
        }

        public abstract void Szervizvizsga();
    }
}