namespace MyApp
{
    class ErtesitesController
    {
        public List<Ertesites> Ertesitesek { get; set; }

        public ErtesitesController(List<Ertesites> ertesitesek)
        {
            Ertesitesek = ertesitesek;
        }

        public void AddErtesites(Ertesites ertesites)
        {
            Ertesitesek.Add(ertesites);
        }

        public void SendRiasztasToAllErtesites(string uzenet)
        {
            foreach (var e in Ertesitesek)
            {
                e.kuld(uzenet);
            }
        }
    }
}