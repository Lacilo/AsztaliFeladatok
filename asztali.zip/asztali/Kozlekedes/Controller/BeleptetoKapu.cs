namespace Kozlekedes
{
    public class BeleptetoKapu
    {
        public BeleptetoKapu()
        {

        }

        public int BevetelSzamitas(List<Utazas> utazasok)
        {
            int osszeg = 0;

            foreach (var u in utazasok)
            {
                osszeg += u.arSzamitas();
            }

            return osszeg;
        }
    }
}