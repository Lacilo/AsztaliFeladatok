using System;

namespace MyApp
{
    class Sms : Ertesites
    {
        public Sms(string tartalom, DateTime datum, string telefonszam) : base(tartalom, datum)
        {
            Telefonszam = telefonszam;
        }

        public string Telefonszam { get; set; }

        public override void kuld(string uzenet = "")
        {
            if(uzenet == "")
            {
                System.Console.WriteLine($"{Telefonszam}: {Tartalom}");
            }
            else
            {
                System.Console.WriteLine(uzenet);
            }            
        }
    }
}