namespace Szerviz
{
    public class Szemelyauto : Jarmu
    {
        public int AjtokSzama { get; set; }

        public Szemelyauto(
            string rendszam,
            int gyartasiEv,
            string allapot,
            int ajtokSzama)
            : base(rendszam, gyartasiEv, allapot)
        {
            AjtokSzama = ajtokSzama;
        }

        public override void Szervizvizsga()
        {
            Console.WriteLine(
                $"{Rendszam}: személyautó szervizvizsgálata"
            );

            Console.WriteLine("- Fékek ellenőrzése");
            Console.WriteLine("- Motor ellenőrzése");
            Console.WriteLine("- Gumiabroncsok ellenőrzése");
            Console.WriteLine($"- Ajtók száma: {AjtokSzama}");
        }
    }
}