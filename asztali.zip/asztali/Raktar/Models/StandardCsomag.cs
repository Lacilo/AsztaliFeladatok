namespace Raktar
{
    public class StandardCsomag : Csomag
    {
        public StandardCsomag(string id, int suly) : base(id, suly)
        {
            Id = id;
            Suly = suly;
        }

        public override string csomagolas()
        {
            return "Csomagolás módja: Kartondobozba kerül, standard ragasztással.";
        }
    }
}