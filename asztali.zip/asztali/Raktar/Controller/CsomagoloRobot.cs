using System.Collections.Generic;

namespace Raktar
{
    public class CsomagoloRobot
    {
        public CsomagoloRobot()
        {

        }

        public void OsszesBecsomagolasa(List<Csomag> csomagok)
        {
            foreach (var csomag in csomagok)
            {
                System.Console.WriteLine(csomag.csomagolas());
            }
        }
    }
}