namespace Szerviz
{
    public class Motorkerekpar : Jarmu
    {
        public Motorkerekpar(
            string rendszam,
            int gyartasiEv,
            string allapot)
            : base(rendszam, gyartasiEv, allapot)
        {
        }

        public override void Szervizvizsga()
        {
            Console.WriteLine(
                $"{Rendszam}: motorkerékpár szervizvizsgálata"
            );

            Console.WriteLine("- Fékek ellenőrzése");
            Console.WriteLine("- Láncfeszesség ellenőrzése");
            Console.WriteLine("- Gumik ellenőrzése");
            Console.WriteLine("- Motor ellenőrzése");
        }
    }
}