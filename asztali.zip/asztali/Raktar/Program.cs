﻿using System;

namespace Raktar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}