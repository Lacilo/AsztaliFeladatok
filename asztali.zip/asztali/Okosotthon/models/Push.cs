using System;

namespace MyApp
{
    class Push : Ertesites
    {
        public Push(string tartalom, DateTime datum) : base(tartalom, datum)
        {
            
        }

        public override void kuld(string uzenet = "")
        {
            if(uzenet == "")
            {
                System.Console.WriteLine($"{Datum} - {Tartalom}");
            }
            else
            {
                System.Console.WriteLine($"{Datum} - {uzenet}");
            }
        }
    }
}