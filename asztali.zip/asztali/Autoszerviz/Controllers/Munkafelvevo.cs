namespace Szerviz
{
    public class Munkafelvevo
    {
        private List<Jarmu> jarmuvek = new List<Jarmu>();

        public void Hozzaad(Jarmu jarmu)
        {
            jarmuvek.Add(jarmu);
        }

        public void Szervizvizsgak()
        {
            foreach (Jarmu jarmu in jarmuvek)
            {
                jarmu.Szervizvizsga();

                Console.WriteLine();
            }
        }
    }
}