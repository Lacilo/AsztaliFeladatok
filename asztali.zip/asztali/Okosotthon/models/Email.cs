using System;

namespace MyApp
{
    class Email : Ertesites
    {
        public Email(string tartalom, DateTime datum, string cim, string targy) : base(tartalom, datum)
        {
            Cim = cim;
            Targy = targy;
        }

        public string Cim { get; set; }
        public string Targy { get; set; }

        public override void kuld(string uzenet = "")
        {
            if(uzenet == "")
            {
                System.Console.WriteLine($"{Cim} - {Targy}\n---\n{Tartalom}");
            }
            else
            {
                System.Console.WriteLine($"{Cim} - {Targy}\n---\n{uzenet}");
            }
        }
    }
}