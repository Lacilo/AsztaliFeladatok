namespace Raktar
{
    public abstract class Csomag
    {
        public Csomag(string id, int suly)
        {
            Id = id;
            Suly = suly;
        }

        public string Id { get; set; }
        public int Suly { get; set; }

        public abstract string csomagolas();
    }
}